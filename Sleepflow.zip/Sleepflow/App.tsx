
import React, { useState, useEffect } from 'react';
import { Page, SleepEntry } from './types';
import Dashboard from './components/Dashboard';
import LogSleep from './components/LogSleep';
import Statistics from './components/Statistics';
import { ICONS } from './constants';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [entries, setEntries] = useState<SleepEntry[]>([]);

  // Mini-Datenbank Logik: Laden beim Start
  useEffect(() => {
    const saved = localStorage.getItem('sleepflow_entries_v2');
    if (saved) {
      try {
        setEntries(JSON.parse(saved));
      } catch (e) {
        console.error("Fehler beim Laden der Daten", e);
      }
    }
  }, []);

  const saveEntry = (entry: SleepEntry) => {
    const updatedEntries = [...entries, entry];
    setEntries(updatedEntries);
    // Mini-Datenbank Logik: Speichern
    localStorage.setItem('sleepflow_entries_v2', JSON.stringify(updatedEntries));
    setCurrentPage('dashboard');
    window.scrollTo(0, 0);
  };

  return (
    <div className="max-w-md mx-auto min-h-screen relative flex flex-col bg-black overflow-x-hidden selection:bg-white/10">
      <main className="flex-1 overflow-y-auto pb-4">
        {currentPage === 'dashboard' && <Dashboard entries={entries} />}
        {currentPage === 'log' && <LogSleep onSave={saveEntry} />}
        {currentPage === 'stats' && <Statistics entries={entries} />}
      </main>

      {/* High-End Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-[100] px-6 pb-8 pointer-events-none">
        <div className="glass backdrop-blur-[30px] px-10 py-5 rounded-[2.5rem] border border-white/10 flex justify-between items-center pointer-events-auto shadow-[0_-10px_40px_rgba(0,0,0,0.5)] relative">
          
          <button 
            onClick={() => setCurrentPage('dashboard')}
            className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${currentPage === 'dashboard' ? 'text-white' : 'text-gray-500 opacity-40'}`}
          >
            <ICONS.Dashboard className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase tracking-widest">Home</span>
            {currentPage === 'dashboard' && <div className="absolute -bottom-1 w-1 h-1 bg-white rounded-full"></div>}
          </button>
          
          <button 
            onClick={() => setCurrentPage('log')}
            className="relative flex flex-col items-center"
          >
            <div className={`w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all duration-500 absolute -top-12 border-[6px] border-black ${currentPage === 'log' ? 'scale-110' : 'scale-100'}`}>
              <ICONS.Log className="w-8 h-8 text-black" />
            </div>
            <span className={`text-[9px] font-bold uppercase tracking-widest mt-6 transition-all ${currentPage === 'log' ? 'text-white opacity-100' : 'text-gray-500 opacity-40'}`}>Log</span>
          </button>

          <button 
            onClick={() => setCurrentPage('stats')}
            className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${currentPage === 'stats' ? 'text-white' : 'text-gray-500 opacity-40'}`}
          >
            <ICONS.Stats className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase tracking-widest">Daten</span>
            {currentPage === 'stats' && <div className="absolute -bottom-1 w-1 h-1 bg-white rounded-full"></div>}
          </button>
        </div>
      </nav>
    </div>
  );
};

export default App;
