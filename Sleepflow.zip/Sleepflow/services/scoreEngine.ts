import { SleepHabits } from '../types';

export const calculateDuration = (bedTime: string, wakeTime: string): number => {
  const [bedH, bedM] = bedTime.split(':').map(Number);
  const [wakeH, wakeM] = wakeTime.split(':').map(Number);

  const now = new Date();
  let bedDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), bedH, bedM);
  let wakeDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), wakeH, wakeM);

  // Wenn die Aufstehzeit vor oder gleich der Zubettgehzeit liegt, ist es der nächste Tag
  if (wakeDate <= bedDate) {
    wakeDate.setDate(wakeDate.getDate() + 1);
  }

  const diffMs = wakeDate.getTime() - bedDate.getTime();
  const diffHrs = diffMs / (1000 * 60 * 60);

  return Math.max(0, diffHrs);
};

export const calculateSleepScore = (duration: number, habits: SleepHabits, mood: number): number => {
  // 50% Dauer Score (Ideal: 7.5 - 8.5 Stunden)
  let durationScore = 0;
  if (duration >= 7.5 && duration <= 8.5) {
    durationScore = 50;
  } else if (duration < 7.5) {
    // Linearer Abzug für zu wenig Schlaf
    durationScore = Math.max(0, (duration / 7.5) * 50);
  } else {
    // Abzug für zu viel Schlaf (Überschlafen macht oft träge)
    durationScore = Math.max(0, 50 - (duration - 8.5) * 10);
  }

  // 30% Habits Score (5 Habits à 6 Punkte)
  const habitCount = Object.values(habits).filter(Boolean).length;
  const habitScore = habitCount * 6;

  // 20% Mood Score (Mood 1-10 -> max 20 Punkte)
  const moodScore = (mood / 10) * 20;

  const total = Math.min(100, Math.round(durationScore + habitScore + moodScore));
  return isNaN(total) ? 0 : total;
};