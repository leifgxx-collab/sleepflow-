
export interface SleepHabits {
  mask: boolean;
  consistentTime: boolean;
  noPhone: boolean;
  brainDumpDone: boolean;
  environmentOptimized: boolean;
}

export interface SleepEntry {
  id: string;
  date: string;
  bedTime: string;
  wakeTime: string;
  morningMood: number; // 1.0 - 10.0
  habits: SleepHabits;
  brainDump: string;
  score: number; // 1 - 100
  duration: number; // in hours
}

export type Page = 'dashboard' | 'log' | 'stats';
