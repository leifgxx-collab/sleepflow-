import React, { useState } from 'react';
import { SleepEntry, SleepHabits } from '../types';
import { calculateDuration, calculateSleepScore } from '../services/scoreEngine';

interface LogSleepProps {
  onSave: (entry: SleepEntry) => void;
}

const LogSleep: React.FC<LogSleepProps> = ({ onSave }) => {
  const [bedTime, setBedTime] = useState('23:00');
  const [wakeTime, setWakeTime] = useState('07:00');
  const [mood, setMood] = useState(7.0);
  const [brainDump, setBrainDump] = useState('');
  const [habits, setHabits] = useState<SleepHabits>({
    mask: false,
    consistentTime: false,
    noPhone: false,
    brainDumpDone: false,
    environmentOptimized: false,
  });

  const handleSave = () => {
    const duration = calculateDuration(bedTime, wakeTime);
    const score = calculateSleepScore(duration, habits, mood);
    
    const today = new Date();
    const dateStr = today.toLocaleDateString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
    
    const entry: SleepEntry = {
      id: Date.now().toString(),
      date: dateStr,
      bedTime,
      wakeTime,
      morningMood: mood,
      habits,
      brainDump,
      score,
      duration,
    };
    
    onSave(entry);
  };

  const toggleHabit = (key: keyof SleepHabits) => {
    setHabits(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex flex-col gap-6 p-6 pb-40 page-transition">
      <h2 className="text-3xl font-bold mt-8 tracking-tight">Schlaf loggen</h2>
      
      <div className="glass rounded-[2rem] p-6 flex flex-col gap-8">
        <div className="grid grid-cols-2 gap-6">
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Bettzeit</label>
            <input 
              type="time" 
              value={bedTime}
              onChange={(e) => setBedTime(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-xl p-4 text-white font-medium focus:outline-none focus:border-white/20 transition-all" 
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Aufstehen</label>
            <input 
              type="time" 
              value={wakeTime}
              onChange={(e) => setWakeTime(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-xl p-4 text-white font-medium focus:outline-none focus:border-white/20 transition-all" 
            />
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <label className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Wie fühlst du dich? (1.0 — 10.0)</label>
          <div className="flex items-center gap-6">
            <input 
              type="range" 
              min="1" 
              max="10" 
              step="0.1" 
              value={mood}
              onChange={(e) => setMood(parseFloat(e.target.value))}
              className="flex-1 accent-white h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer"
            />
            <span className="text-2xl font-light w-16 text-center tabular-nums">{mood.toFixed(1).replace('.', ',')}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <h3 className="text-[11px] font-bold text-gray-500 uppercase tracking-[0.2em] px-2 mb-1">Checkliste</h3>
        {[
          { key: 'mask', label: '1. Schlafmaske benutzt' },
          { key: 'consistentTime', label: '2. Konstante Zeiten (23h-7h)' },
          { key: 'noPhone', label: '3. Handy vorm Schlafen (max 30m)' },
          { key: 'brainDumpDone', label: '4. Brain Dump gemacht' },
          { key: 'environmentOptimized', label: '5. Umgebung optimiert' },
        ].map((item) => (
          <button
            key={item.key}
            onClick={() => toggleHabit(item.key as keyof SleepHabits)}
            className={`flex items-center justify-between p-5 rounded-2xl border transition-all duration-300 ${
              habits[item.key as keyof SleepHabits] 
                ? 'bg-white/10 border-white/20 shadow-lg' 
                : 'bg-white/[0.02] border-white/5 opacity-40'
            }`}
          >
            <span className="text-sm font-medium tracking-tight">{item.label}</span>
            <div className={`w-5 h-5 rounded-full flex items-center justify-center border transition-all ${
              habits[item.key as keyof SleepHabits] ? 'bg-white border-white' : 'border-white/20'
            }`}>
              {habits[item.key as keyof SleepHabits] && (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={4} stroke="black" className="w-3 h-3">
                  <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
              )}
            </div>
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-[10px] text-gray-500 uppercase font-bold tracking-widest px-2">Brain Dump Gedanken</label>
        <textarea
          placeholder="Business, To-Dos, offene Gedanken..."
          value={brainDump}
          onChange={(e) => setBrainDump(e.target.value)}
          rows={4}
          className="glass rounded-2xl p-5 text-white text-sm placeholder-gray-700 border-white/5 focus:outline-none focus:border-white/20 resize-none transition-all"
        />
      </div>

      <button 
        onClick={handleSave}
        className="w-full bg-white text-black font-bold py-5 rounded-2xl shadow-[0_20px_40px_rgba(255,255,255,0.1)] active:scale-[0.97] transition-all uppercase tracking-widest text-xs mt-4"
      >
        Schlaf speichern
      </button>
    </div>
  );
};

export default LogSleep;