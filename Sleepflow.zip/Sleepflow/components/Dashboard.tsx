import React from 'react';
import { SleepEntry } from '../types';

interface DashboardProps {
  entries: SleepEntry[];
}

const Dashboard: React.FC<DashboardProps> = ({ entries }) => {
  const lastEntry = entries[entries.length - 1];
  
  const averageScore = entries.length 
    ? Math.round(entries.reduce((acc, curr) => acc + curr.score, 0) / entries.length) 
    : 0;
  
  const averageDuration = entries.length 
    ? (entries.reduce((acc, curr) => acc + curr.duration, 0) / entries.length).toFixed(1)
    : "0.0";

  return (
    <div className="flex flex-col gap-6 p-6 pb-32 animate-in fade-in duration-700">
      <header className="mt-8 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Hallo, Leif</h1>
          <p className="text-gray-500 text-sm mt-1 uppercase tracking-widest text-[10px] font-bold">Performance Übersicht</p>
        </div>
      </header>

      {/* Main Score Card */}
      <div className="glass-card rounded-[2.5rem] p-10 flex flex-col items-center justify-center relative overflow-hidden border-white/5 shadow-2xl">
        <div className="absolute top-[-20%] left-[-10%] w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        
        <span className="text-gray-500 text-[10px] font-bold uppercase tracking-[0.25em] mb-4">Aktueller Schlaf-Score</span>
        <div className="text-8xl font-light text-white mb-4 tabular-nums tracking-tighter">
          {lastEntry?.score || 0}
        </div>
        <div className="px-6 py-2 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/60">
          {lastEntry?.score && lastEntry.score > 85 ? 'Exzellent' : lastEntry?.score && lastEntry.score > 60 ? 'Stabil' : lastEntry?.score ? 'Optimierbar' : 'Bereit für Log'}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="glass rounded-3xl p-6 flex flex-col gap-1 border-white/5 shadow-inner">
          <span className="text-[9px] text-gray-500 uppercase font-bold tracking-widest">Durchschnitt</span>
          <span className="text-3xl font-bold tabular-nums tracking-tight">{averageScore}%</span>
        </div>
        <div className="glass rounded-3xl p-6 flex flex-col gap-1 border-white/5 shadow-inner">
          <span className="text-[9px] text-gray-500 uppercase font-bold tracking-widest">Ø Dauer</span>
          <span className="text-3xl font-bold tabular-nums tracking-tight">{averageDuration}h</span>
        </div>
      </div>

      <h2 className="text-lg font-bold mt-4 tracking-tight uppercase text-gray-500 text-[11px] px-1 tracking-[0.2em]">Letzter Eintrag</h2>
      {lastEntry ? (
        <div className="flex flex-col gap-4">
          <div className="glass rounded-[2rem] p-5 flex justify-between items-center border-white/5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-white/80">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
                </svg>
              </div>
              <div>
                <p className="text-[9px] text-gray-500 uppercase font-bold tracking-wider">Intervall</p>
                <p className="text-sm font-semibold tabular-nums">{lastEntry.bedTime} — {lastEntry.wakeTime}</p>
              </div>
            </div>
            <div className="text-right px-2">
              <p className="text-[9px] text-gray-500 uppercase font-bold tracking-wider">Datum</p>
              <p className="text-sm font-semibold">{lastEntry.date}</p>
            </div>
          </div>

          <div className="glass rounded-[2rem] p-6 border-white/5">
            <p className="text-[9px] text-gray-500 uppercase font-bold tracking-widest mb-4">Habit Status</p>
            <div className="flex gap-2 flex-wrap">
              {Object.entries(lastEntry.habits).map(([key, val]) => (
                val && (
                  <span key={key} className="px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-[9px] uppercase font-bold text-gray-300">
                    {key === 'mask' && 'Schlafmaske'}
                    {key === 'consistentTime' && 'Zeit-Treue'}
                    {key === 'noPhone' && 'Handy-Abstinenz'}
                    {key === 'brainDumpDone' && 'Brain Dump'}
                    {key === 'environmentOptimized' && 'Klima/Dunkel'}
                  </span>
                )
              ))}
              {!Object.values(lastEntry.habits).some(v => v) && (
                <span className="text-[10px] text-gray-600 font-medium">Keine Habits erfüllt</span>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="glass rounded-[2rem] p-12 text-center text-gray-600 border-white/5 text-sm leading-relaxed">
          Noch keine Daten vorhanden.<br/>
          <span className="text-[10px] uppercase tracking-widest mt-2 block opacity-50">Logge deinen ersten Schlaf!</span>
        </div>
      )}
    </div>
  );
};

export default Dashboard;