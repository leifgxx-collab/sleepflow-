
import React from 'react';
import { SleepEntry } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface StatisticsProps {
  entries: SleepEntry[];
}

const Statistics: React.FC<StatisticsProps> = ({ entries }) => {
  if (entries.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[80vh] text-gray-600 p-8 text-center gap-6 animate-in fade-in duration-500">
        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center border border-white/10 text-xl">📊</div>
        <p className="text-sm font-medium leading-relaxed">Noch nicht genügend Daten für eine Analyse.<br/>Fange an zu loggen!</p>
      </div>
    );
  }

  const chartData = entries.slice(-7).map(e => ({
    name: e.date.split('.')[0] + '.' + e.date.split('.')[1],
    score: e.score,
    duration: e.duration,
  }));

  return (
    <div className="flex flex-col gap-6 p-6 pb-36 animate-in fade-in slide-in-from-right duration-500">
      <h2 className="text-3xl font-bold mt-8 tracking-tight">Deine Statistik</h2>

      <div className="glass rounded-[2rem] p-6 border-white/5">
        <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-8">Score Verlauf (7 Tage)</h3>
        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FFFFFF" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#FFFFFF" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="name" stroke="#444" fontSize={9} axisLine={false} tickLine={false} tickMargin={12} />
              <YAxis stroke="#444" fontSize={9} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip 
                cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1 }}
                contentStyle={{ backgroundColor: '#000', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="score" stroke="#FFFFFF" fillOpacity={1} fill="url(#colorScore)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="glass rounded-[2rem] p-6 border-white/5">
        <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-8">Schlafdauer (Std)</h3>
        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="name" stroke="#444" fontSize={9} axisLine={false} tickLine={false} tickMargin={12} />
              <YAxis stroke="#444" fontSize={9} axisLine={false} tickLine={false} />
              <Tooltip 
                cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1 }}
                contentStyle={{ backgroundColor: '#000', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Line type="monotone" dataKey="duration" stroke="#FFFFFF" strokeWidth={2} dot={{ fill: '#000', stroke: '#fff', strokeWidth: 2, r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-6 border-white/5">
          <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Max Score</span>
          <p className="text-3xl font-light tabular-nums mt-1">{Math.max(...entries.map(e => e.score))}%</p>
        </div>
        <div className="glass rounded-2xl p-6 border-white/5">
          <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Max Dauer</span>
          <p className="text-3xl font-light tabular-nums mt-1">{Math.max(...entries.map(e => e.duration)).toFixed(1)}h</p>
        </div>
      </div>
    </div>
  );
};

export default Statistics;
